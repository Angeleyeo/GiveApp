package com.example.giveapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.squareup.picasso.Picasso;

public class foodDetails extends AppCompatActivity {

    private static final String TAG = "foodDetails";

    TextView foodName, foodDesc, counterTxt;
    Button plusBtn, minusBtn, confirmBtn;
    private int counter;
    ImageView foodLogo;
    CollapsingToolbarLayout collapsingToolbarLayout;
    FloatingActionButton btnBuy;

    Food food;

    FirebaseFirestore db;
    CollectionReference foodCollection;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_details);

        counterTxt = (TextView) findViewById(R.id.counterText);

        db = FirebaseFirestore.getInstance();
        foodCollection = db.collection("food");

        btnBuy = (FloatingActionButton) findViewById(R.id.buyBtn);

        foodDesc = (TextView) findViewById(R.id.foodDesc);
        foodName = (TextView) findViewById(R.id.foodName);
        foodLogo = (ImageView) findViewById(R.id.foodLogo);

        collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing);
        collapsingToolbarLayout.setExpandedTitleTextAppearance(R.style.ExpandedAppbar);
        collapsingToolbarLayout.setCollapsedTitleTextAppearance(R.style.CollapsedAppbar);

        plusBtn = (Button) findViewById(R.id.addQtyBtn);
        minusBtn = (Button) findViewById(R.id.reduceQtyBtn);
        confirmBtn = (Button) findViewById(R.id.confirmBtn);

        if (getIntent() != null) {
            food = (Food) getIntent().getSerializableExtra("food");
        }
        assert food != null;
        getDetail(food);
        initCounter();


        plusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter++;
                counterTxt.setText(String.valueOf(counter));
            }
        });

        minusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter--;
                counterTxt.setText(String.valueOf(counter));
            }
        });

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    private void getDetail(final Food food) {
        foodCollection.document(food.getId()).addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {

                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    return;
                }

                if (documentSnapshot != null && documentSnapshot.exists()) {
                    Log.d(TAG, "Current data: " + documentSnapshot.getData());
                    foodName.setText((String) documentSnapshot.get("foodName"));
                    foodDesc.setText((String) documentSnapshot.get("foodDesc"));
                    Picasso.get().load((String) documentSnapshot.get("foodLogo")).into(foodLogo);

                   // SharedPreferences sp = getSharedPreferences("foodIDSP", MODE_PRIVATE);
                    //sp.edit().putString("foodID", documentSnapshot.getId()).apply();

                } else {
                    Log.d(TAG, "Current data: null");
                }
                collapsingToolbarLayout.setTitle(foodName.getText());
            }

        });

    }

    public void initCounter() {
        counter = 0;
        counterTxt.setText(String.valueOf(counter));
    }



}