package com.example.giveapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class iCU_uncompleted extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_i_c_u_uncompleted);
    }
}